# WDL-PRACS-LIST
This repository contains solution to all the questions given for WDL practical exam. 😉<br />
Experience the Guess The Code Game here: http://guessthecode.surge.sh/ <br />
Note that you need to shuffle first to generate random numbers.
Experience the College website here: http://praccollege.surge.sh/ <br />
Experience the Facebook like login page here: http://pracfacebook.surge.sh/ <br />
Experience the Color Changer here: http://praccolorchanger.surge.sh/ <br />
Experience the Toy Bill Generator here: http://gamebill.surge.sh/ <br />
# Kindly note that XML files are supported only by internet explorer, firefox doesn't support the xsl stylesheet <br />
To run in lab pc do the following:
1. On cmd - $php -S localhost:5000
2. On broswer - http://localhost:5000/FILENAME.xml
